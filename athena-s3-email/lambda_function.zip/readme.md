# Athena s3 email 

This lambda function is to trigger SES email from any files written to s3 by Athena runner

<br/>
 
Run below code to get all the dependencies for the code : 
```
pip install requests -t ./
zip -r9 ../lambda_function.zip .
```

<br/>

Then upload the lambda_function.zip