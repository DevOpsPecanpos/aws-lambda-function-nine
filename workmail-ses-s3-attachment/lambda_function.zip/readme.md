# Athena s3 email 

This lambda function is to receive AWS Workmail email. Once we receive the workmail in S3, trigger the lambda function to extract the attachment from the email and place it according to the sender name and email subject as s3 folder structure. Then a file-transfer will be needed be set up to transfer the files to athena folder.

<br/>
 
Run below code to get all the dependencies for the code : 
```
pip install -r requirements.txt -t ./
zip -r9 ../lambda_function.zip .
```

<br/>

Then upload the lambda_function.zip